package edu.uoc.orimarkettfm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class listaPedidosNegocio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_pedidos_negocio);
    }
}
