package edu.uoc.orimarkettfm.clases;

public class CustomAdapterBusqueda {
}
