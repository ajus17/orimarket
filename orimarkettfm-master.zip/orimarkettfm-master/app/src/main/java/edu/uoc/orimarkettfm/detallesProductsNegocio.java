package edu.uoc.orimarkettfm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class detallesProductsNegocio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_products_negocio);
    }
}
